<?php
$servername = "localhost";
$patientName = $_POST['Patient_Name'];
$dateOfBirth = $_POST['Date_of_Birth'];
$motherName = $_POST['Parents_Names'];
$NationalNumber = $_POST['National_ID'];
$phoneNumber= $_POST['P_Number'];
$weight = $_POST['Weight'];
$address = $_POST['Adress'];
$date = $_POST['Date'];

// Create connection
$conn = new mysqli($servername, "root","","BMD");
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
else {
    $stm = $conn->prepare("insert into Appoint(Patient_Name,Date_of_Birth,Parents_Names,National_ID,P_Number,Weight,Adress,Date)
    values(?,?,?,?,?,?,?,?)");
    $stm->bind_param("sssiidss",$patientName, $dateOfBirth, $motherName, $NationalNumber, $phoneNumber, $weight, $address, $date);
    $stm->execute();
    echo "Connected successfully";
    $stm->close();
    $conn->close();
}
?>